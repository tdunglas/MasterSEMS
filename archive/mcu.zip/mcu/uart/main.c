#include "stm32f3xx_hal.h"

void MX_GPIO_Init (void);
void MX_USART_Init (UART_HandleTypeDef*);

int 
main ()
{
  HAL_Init ();

  // =========
  // GPIO INIT

  MX_GPIO_Init ();

  // =========
  // USART INIT

  UART_HandleTypeDef uart_handle = { 0 };
  MX_USART_Init (&uart_handle);
  
  // =========
  // USER INIT

  char buf[] = "* mississippi ";

  // =========
  // WHILE

  while (1)
  {
    //HAL_UART_Transmit(&uart_handle, buf, 1, 500);
    if (HAL_UART_Receive (&uart_handle, buf, 1, 500) == HAL_OK)
    {
       HAL_UART_Transmit (&uart_handle, buf, sizeof(buf), 500);
     }
  }
}

void 
MX_GPIO_Init (void)
{
  __HAL_RCC_GPIOC_CLK_ENABLE ();

  GPIO_InitTypeDef gpio_init = { 0 };
  gpio_init.Pin = GPIO_PIN_4 | GPIO_PIN_5;
  gpio_init.Mode = GPIO_MODE_AF_PP;
  gpio_init.Pull = GPIO_NOPULL;
  gpio_init.Speed = GPIO_SPEED_FREQ_LOW;
  gpio_init.Alternate = GPIO_AF7_USART1;

  HAL_GPIO_Init (GPIOC, &gpio_init);
}

void 
MX_USART_Init (UART_HandleTypeDef *uart_handle)
{
  __HAL_RCC_USART1_CLK_ENABLE ();

  uart_handle->Instance = USART1;
  uart_handle->Init.BaudRate = 9600;
  uart_handle->Init.WordLength = UART_WORDLENGTH_8B;
  uart_handle->Init.Mode = UART_MODE_TX_RX;

  HAL_UART_Init (uart_handle);
}

void 
SysTick_Handler (void)
{
  HAL_IncTick();
}