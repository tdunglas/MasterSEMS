http://cedric.cnam.fr/~puechm/ens/usrs26/
