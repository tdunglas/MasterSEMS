#include "stm32f3xx.h"
#include "stm32f3xx_hal.h"
#include "leds.h"
#include "button.h"

#define FREQ 128
const unsigned char* msg = "hello";
UART_HandleTypeDef huart = {0}; 

void delay() {
    for (float x=0.0f; x<1.0f; x += 0.00001f);
}

int main()
{
    HAL_Init();

    stmtp_init_leds();
    stmtp_init_button();
    
    __HAL_RCC_USART1_CLK_ENABLE();
    
    UART_InitTypeDef init = {0};
    init.BaudRate = 9600;
    init.WordLength = UART_WORDLENGTH_8B;
    init.StopBits = UART_STOPBITS_1_5;
    init.Parity = UART_PARITY_NONE;
    init.Mode = UART_MODE_TX_RX;
    init.HwFlowCtl = UART_HWCONTROL_RTS_CTS;
    init.OverSampling = UART_OVERSAMPLING_8;
    init.OneBitSampling = UART_ONE_BIT_SAMPLE_ENABLE;
    
    huart.Instance = USART1;
    huart.Init = init; 
    
    HAL_NVIC_EnableIRQ(USART1_IRQn);
    stmtp_set_led(6, 1);
    
    //HAL_UART_Transmit_IT(&huart, &msg, sizeof(msg));
    HAL_UART_Receive_IT(&huart, (unsigned char*)msg, sizeof(msg));
    while(1) { __WFI(); }
}

void USART1_IRQHandler() {    
    HAL_UART_IRQHandler(&huart);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *UartHandle) {
    //stmtp_clign_1();
    stmtp_set_led(0, 1);
    HAL_UART_Transmit_IT(&huart, (unsigned char*)msg, sizeof(msg));
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *UartHandle) {
    HAL_UART_Receive_IT(&huart, (unsigned char*)msg, sizeof(msg));
}
/*
void SysTick_Handler()
{
    static char cnt;

    if (!(++cnt % FREQ))
    {
    stmtp_set_led(3, 1);
    }
    else if ((++cnt % FREQ) > 10
        && (++cnt % FREQ) < 100)
    {
        stmtp_set_all(0);
    }
}*/
