#include "stm32f3xx.h"
#include "stm32f3xx_hal.h"
UART_HandleTypeDef huart = {0}; 

int _read(int file, char *data, int len) {
    HAL_UART_Transmit_IT(&huart, data, len);
    return len;
}

int _write(int file, char *data, int len) {
    HAL_UART_Receive_IT(&huart, data, 1);
    return len;
}

void printf_it(unsigned char* data, int len) {
    HAL_UART_Transmit_IT(&huart, data, len);
}

void scanf_it() {
    unsigned char data = 0;
    HAL_UART_Receive_IT(&huart, &data, 1);
}
