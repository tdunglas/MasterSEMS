package com.example.licencep.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class activity_home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Intent intent = getIntent();
        String message = intent.getStringExtra("login");


        TextView textView = (TextView)findViewById(R.id.tv_text2);
        textView.setText("welcome " + message);

        Button map = (Button)findViewById(R.id.map);
        Button nav = (Button)findViewById(R.id.nav);

        map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("geo:48.860522, 2.357919?q=60+Rue+des+Francs+Bourgeois+75003+Paris");
            }
        });

        nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent("https://www.google.fr/");
            }
        });
    }

    public void startIntent(String val){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(val));

        if(intent.resolveActivity(getPackageManager()) != null){
            startActivity(intent);
        }
    }

}
