package logic;

import java.util.HashMap;

public class Et extends Operateur{

	public static String op = "/\\";
	
	public Et(Formule f1, Formule f2) {
		super(f1, f2, op);
	}

	@Override
	public boolean eval(HashMap<String, Boolean> hash) {
		return left.eval(hash) && right.eval(hash);
	}

}
