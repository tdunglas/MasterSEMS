package logic;

import java.util.HashMap;
import java.util.Set;

public abstract class Operateur extends Formule{

	public Formule left;
	public Formule right;
	
	public Operateur(Formule f1, Formule f2, String op){
		super(op);
		left = f1;
		right = f2;
	}
	
	@Override
	public abstract boolean eval(HashMap<String, Boolean> hash);
	
	@Override
	public String toString() {
		return left + super.val + right;
	}
	
	@Override
	public void getAtoms(Set<Atom> atoms) {
		left.getAtoms(atoms);
		right.getAtoms(atoms);
	}

}
