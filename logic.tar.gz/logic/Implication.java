package logic;

import java.util.HashMap;

public class Implication extends Operateur{
	
	public static String op = "=>";
	
	public Implication(Formule f1, Formule f2){
		super(f1,f2,op);
	}

	@Override
	public boolean eval(HashMap<String, Boolean> hash) {
		if(!left.eval(hash) || 
				(left.eval(hash) && right.eval(hash))){
			return true;
		}
		
		return false;
	}
}
