package logic;

import java.util.HashMap;
import java.util.Set;

public class Negation extends Formule {
	
	private Formule fm;
	
	public Negation(Formule f){
		super("!(" + f.toString() + ")");
		this.fm = f;
	}
	
	@Override
	public boolean eval(HashMap<String, Boolean> hash) {
		return !fm.eval(hash);
	}

	@Override
	public String toString() {
		return super.val;
	}

	@Override
	public void getAtoms(Set<Atom> atoms) {
		fm.getAtoms(atoms);
	}
}
