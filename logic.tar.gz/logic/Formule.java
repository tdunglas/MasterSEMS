package logic;

import java.util.HashMap;
import java.util.Set;

public abstract class Formule {
	
	public String val;
	
	public Formule(String s){
		val = s;
	}
	
	public abstract boolean eval(HashMap<String, Boolean> hash);
	
	public abstract String toString();
	
	public abstract void getAtoms(Set<Atom> atoms);
	
}
