package logic;

import java.util.HashMap;
import java.util.Set;

public class Atom extends Formule {

	public Atom(String s){
		super(s);
	}
	
	@Override
	public boolean eval(HashMap<String, Boolean> hash) {
		return hash.get(super.val);
	}
	
	public String toString(){
		return super.val;
	}

	@Override
	public void getAtoms(Set<Atom> atoms) {
		// TODO Auto-generated method stub
		atoms.add(this);
	}

}
