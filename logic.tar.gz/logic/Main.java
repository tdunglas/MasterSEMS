package logic;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Main {

	public static void main(String[] args) {

		Atom a = new Atom("A");
		Atom b = new Atom("B");
		Atom c = new Atom("C");
		Atom d = new Atom("D");

		Implication imp = new Implication(a,b);
		Implication imp2 = new Implication(c, new Ou(d, imp));
		Ou ou = new Ou(a,b);
		Et et = new Et(a,b);
		Negation negation = new Negation(a);
		
		HashMap<String, Boolean> hash = new HashMap<String, Boolean>();
		
		/*
		System.out.println(imp);
		System.out.println(ou);
		System.out.println(et);
		System.out.println(negation);
		System.out.println(new Negation(new Ou(a,b)));

		hash.put("A", true);
		hash.put("!(A)", true);
		hash.put("B", false);
		
		System.out.println(imp.eval(hash));

		imp = new Implication(a,a);
		System.out.println(imp.eval(hash));
		
		imp = new Implication(a,new Negation(a));
		System.out.println(imp.eval(hash));
		*/
		
		truthTable(imp2);
	}
	
	public static void truthTable(Formule fm){
		Set<Atom> set = new HashSet<>();
		fm.getAtoms(set);
		
		Map<String, Boolean> hash = new HashMap<String, Boolean>(set.size());
		
		Iterator<Atom> itr = set.iterator();
		while (itr.hasNext()) {
			Atom a = itr.next();
			hash.put(a.val, false);
		}
		
		String[] katoms = (String[]) hash.keySet().toArray(new String[hash.keySet().size()]);
		
		for (int i = 0; i < Math.pow(2, katoms.length); i++) 
		{
			int j = 0;
			if (i > 0) {
				for (j = 0; j < katoms.length; j++) {
					if (!hash.get(katoms[j])) {
						hash.put(katoms[j], true);
						break;
					}
				}
			}
			
			for (int k = j - 1; k >= 0; k--) {
				if (hash.get(katoms[k])) {
					hash.put(katoms[k], false);
				}
			}
			
			boolean val = fm.eval((HashMap<String, Boolean>) hash);
			
			for(String str : hash.keySet()){
				System.out.print(str + " " + hash.get(str) + " | ");
			}
			System.out.println(fm + " " + val);
		}
	}

}
