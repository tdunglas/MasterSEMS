package logic;

import java.util.HashMap;

public class Ou extends Operateur{

	public static String op = "\\/";
	
	public Ou(Formule f1, Formule f2) {
		super(f1, f2, op);
	}

	@Override
	public boolean eval(HashMap<String, Boolean> hash) {
		return left.eval(hash) || right.eval(hash);
	}

}
