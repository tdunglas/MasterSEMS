/* Établie une session TCP vers srv_name sur le port srv_port
 * char *srv_name: nom du serveur (peut-être une adresse IP)
 * int srv_port: port sur lequel la connexion doit être effectuée
 *
 * renvoie: descripteur vers le socket
 */ 
int connect_to_server(char *srv_name, char *srv_port){
  //struct hostent *host;
  //struct sockaddr_in sock_addr;
  struct addrinfo hints;
  struct addrinfo *result, *rp;
  int ret_code;
  
    
  //struct in_addr ip_addr;
  int clt_sock;

  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_UNSPEC;     /* Allow IPv4 or IPv6 */
  hints.ai_socktype = SOCK_STREAM; /* Stream socket */

  ret_code = getaddrinfo(srv_name, srv_port, &hints, &result);
  if ( ret_code != 0 ) 
    {
      fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(ret_code));
      return -1;
    }

  for (rp = result; rp != NULL; rp = rp->ai_next) {
    clt_sock = socket(rp->ai_family, rp->ai_socktype,
		 rp->ai_protocol);
    if (clt_sock == -1) 
      continue; // 
    
    if (connect(clt_sock, rp->ai_addr, rp->ai_addrlen) != -1)
      break;         /* Connection succeeded */

    /* else try next entry */
    close(clt_sock);
  }
  
  if (rp == NULL){  /* No address succeeded */
    PERROR("socket");
    freeaddrinfo(result); /* no longer needed */
    return -1;
  }

  freeaddrinfo(result); /* no longer needed */

  return clt_sock;
}
