int create_a_listening_socket(char *srv_port, int maxconn){
  struct addrinfo hints;
  struct addrinfo *result, *rp;
  int ret_code;
  int srv_sock;
  
  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_UNSPEC;       /* For IPv4 and IPv6*/
  hints.ai_socktype = SOCK_STREAM; /* Datagram socket */
  hints.ai_flags = AI_PASSIVE | AI_ALL;    /* For wildcard IP address */

  ret_code = getaddrinfo(NULL, srv_port, &hints, &result);
  if (ret_code != 0) {
    fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(ret_code));
    return -1;
  }
  
  for (rp = result; rp != NULL; rp = rp->ai_next) {
    srv_sock = socket(rp->ai_family, rp->ai_socktype,
		 rp->ai_protocol);
    if (srv_sock == -1)
      continue;
      
    if (bind(srv_sock, rp->ai_addr, rp->ai_addrlen) == 0) 
      break;
    
    close(srv_sock);
  }
  
  if (rp == NULL ) {               /* No address succeeded */
    fprintf(stderr, "Could not bind\n");
    return -1;
  }
  
  freeaddrinfo(result);           /* No longer needed */

  if (listen(srv_sock, maxconn) == -1) {
    PERROR("listen");
    DEBUG("error within listen");
    return -1;
  }
  
  return srv_sock;
}
