#include "common.h"
#include "chatroom.h"
#include <signal.h>
#include <pthread.h>

#define MAX_CONN 10            // nombre maximale de requêtes en attentes

int DFLAG;
int srv_sock;

int create_a_listening_socket(char *srv_port, int maxconn){
  struct addrinfo hints;
  struct addrinfo *result, *rp;
  int ret_code;
  int srv_sock;
  
  memset(&hints, 0, sizeof(struct addrinfo));
  hints.ai_family = AF_UNSPEC;       /* For IPv4 and IPv6*/
  hints.ai_socktype = SOCK_STREAM; /* Datagram socket */
  hints.ai_flags = AI_PASSIVE | AI_ALL;    /* For wildcard IP address */

  ret_code = getaddrinfo(NULL, srv_port, &hints, &result);
  if (ret_code != 0) {
    fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(ret_code));
    return -1;
  }
  
  for (rp = result; rp != NULL; rp = rp->ai_next) {
    srv_sock = socket(rp->ai_family, rp->ai_socktype,
		 rp->ai_protocol);
    if (srv_sock == -1)
      continue;
      
    if (bind(srv_sock, rp->ai_addr, rp->ai_addrlen) == 0) 
      break;
    
    close(srv_sock);
  }
  
  if (rp == NULL ) {               /* No address succeeded */
    fprintf(stderr, "Could not bind\n");
    return -1;
  }
  
  freeaddrinfo(result);           /* No longer needed */

  if (listen(srv_sock, maxconn) == -1) {
    PERROR("listen");
    DEBUG("error within listen");
    return -1;
  }
  
  return srv_sock;
}

int accept_clt_conn(int srv_sock, struct sockaddr_in *clt_sockaddr){
  int clt_sock;
  socklen_t addrlen;

  clt_sock = accept(srv_sock, 
		    (struct sockaddr *)clt_sockaddr,
		    (socklen_t *)&addrlen);

  if (clt_sock == -1) {
    PERROR("accept");
    return -1;
  }

  DEBUG("connexion accepted");

  return clt_sock;
}

int main(void) 
{
  DFLAG = 1;

  /* create a listening socket */
  srv_sock = create_a_listening_socket(SRV_PORT, MAX_CONN);
  if (srv_sock < 0) 
    {
      DEBUG("failed to create a listening socket");
      exit(EXIT_FAILURE);
    }
  
  /* initialize the chat room with no client */
  initialize_chat_room();
    
  while (1){
    int clt_sock;
    struct sockaddr_in clt_sockaddr;
    char *clt_ip;
    int clt_port;
    
    /* wait for new incoming connection */
    if ((clt_sock = accept_clt_conn(srv_sock, &clt_sockaddr)) < 0 ) 
      {
	perror("accept_clt_conn");	
	exit(EXIT_FAILURE);
      }

    clt_ip = inet_ntoa(clt_sockaddr.sin_addr);
    clt_port = ntohs(clt_sockaddr.sin_port);
    
    /* register new buddies in the chat room */
    if ( login_chatroom(clt_sock, clt_ip, clt_port) != 0 ) 
      {
	DEBUG("client %s:%d not accepted", clt_ip, clt_port);	
	close(clt_sock);
	DEBUG("close clt_sock %s:%d", clt_ip, clt_port);
      }
    
  } /* while */

  return EXIT_SUCCESS;
}
